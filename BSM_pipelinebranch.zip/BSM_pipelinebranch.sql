prompt Importing table piplinebranch...
set feedback off
set define off
insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43653486', '615', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '330100', null, '���ݼ�������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43194869', '101', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ���۹㳡֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43676452', '401', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ����ʹ󶼴󷹵�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43220656', '201', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43462266', '301', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��λ�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43601588', '001', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43880949', '200', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ����������ǾƵ�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43765121', '601', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43555313', '806', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '����Զ��·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43866174', '406', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '����Ӣ�����ʽ�������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43948911', '018', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440000', null, '��ݸ����');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43757264', '509', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '������ӳ�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('44085844', '202', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '�����������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43635059', '402', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '���ڸ���������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43812035', '002', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '���ڷ���');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43273864', '115', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '330100', null, '��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43437616', '315', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '330100', null, '���ݻ���֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43540111', '025', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '340100', null, '�Ϸʷ���');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43804839', '120', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '330200', null, '��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43461713', '301', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��λ�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43310242', '801', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����˹�㳡֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43613307', '451', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43509534', '611', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ���̲֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43467669', '701', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43511274', '253', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��ű�·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43482187', '511', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ���ɽ��԰֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43461309', '531', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43557518', '001', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ���������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('34037337', '153', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43308065', '231', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ���̩֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43367446', '031', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43682152', '601', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��ֶ������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43544161', '431', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43369124', '501', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�����·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43311120', '053', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ���Ϫ·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43462352', '901', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ������ֳ�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43191175', '401', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�̩��·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('34048912', '100', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ����ʹ󶼴󷹵�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('34017933', '131', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��̳�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('34015325', '251', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ����·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43366467', '331', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43631024', '110', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '310100', null, '�Ϻ�������������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43381308', '210', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '320500', null, '��������㳡֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('34065544', '310', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '320500', null, '���ݻ�����ʴ���֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43380456', '308', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '320500', null, '���ݹ�ҵ԰���ջ�·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('34300263', '403', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '350200', null, '���ű���֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43837530', '296', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '350200', null, '���ź���֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43478812', '096', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '���������㳡֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43179101', '396', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '������΢·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43365220', '406', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '������ֱ��֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43722446', '196', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '����Ӣ�����ʽ�������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43548754', '906', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '�����⻪·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43718638', '106', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '������ó֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43182540', '706', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43309869', '596', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43459995', '606', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '�����廪�Ƽ�԰֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43509894', '206', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '�����йش�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43459100', '306', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '�����йش�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43609328', '506', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '������ɯ����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43906727', '517', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43361907', '312', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '110100', null, '��������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43558993', '212', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '510100', null, '�ɶ������³�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43740792', '112', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '510100', null, '�ɶ��ٽ���·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43532593', '311', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '510100', null, '�ɶ�������·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43953007', '407', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '500100', null, '���챱�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43772120', '023', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '210200', null, '������ƽ�㳡֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43290974', '204', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '370100', null, '���Ϸ���');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43429622', '017', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '370200', null, '�ൺɽ��·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43352285', '117', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '210100', null, '��������');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43288751', '205', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '210100', null, '����������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43722737', '116', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '120100', null, '�����ʴ���֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43951228', '338', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '610100', null, '���������֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43643250', '528', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440000', null, '��ݸ����·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43511560', '419', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440000', null, '��ݸӭ��·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43690255', '299', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440200', null, '��ɽ�Ϻ����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43207942', '409', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440200', null, '˳��֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43299263', '209', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '���ݽ�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43288729', '469', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '�������Ź㳡֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43709204', '199', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '���ݻ�ɳ֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43708506', '102', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '�����齭�³�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43935715', '009', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '���ݽ���·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('34063499', '809', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '���ݷ���');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43707058', '302', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440100', null, '������ɽ·�ĵ�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('12039701', '602', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '������ɽ֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43310165', '502', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '���ڼα�·֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43411319', '092', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '���ڻ��ȳ�֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43772124', '492', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '���ں�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43395846', '702', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '�����찲�����֧��');

insert into piplinebranch (STAFFID, BRANCHCODE, OPERATOR, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME, BAK1, BAK2, BRANCHNAME)
values ('43568307', '192', 'ybt', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', to_date('25-10-2019', 'dd-mm-yyyy'), '20:20:20', '440300', null, '���ڻ�ǿ��·֧��');
commit;
prompt Done.
