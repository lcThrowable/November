function queryParams(params) { 
	// 设置查询参数
	var param = {
		limit : params.limit,
		offset : params.offset,
		sortName : params.sort,// 排序列名
		sortOrder : params.order,// 排位命令（desc，asc）
		pageSize : params.pageSize,
		pageNumber : params.pageNumber,
		year:$("#year").val().trim(),
	};
	return param;
};

$(function(){
	$("#year").val(new Date().getFullYear());
	//点击查询加载bootstrap数据表格
	$("#search").click(function(){
		var year=$("#year").val().trim();
		if(""!=year){
			init(year);	
		}else{
			$("#monthlyTable").bootstrapTable('destroy');
			layer.tips('请选择月结年份',"#year",{
				 tips: [1, '#DB0011'] //还可配置颜色
			});
		}
	});
	$("#reset").click(function(){
		$("#monthlyTable").bootstrapTable('destroy');
	});
	
});

function init(year){
	var showdilog= layer.load(2, {
		  shade:0.3, //0.2透明度的白色背景
	 });
	 $("#monthlyTable").bootstrapTable('destroy');
	 $.ajax({
		 url : path+"/monthlyStatementController/holidayNumQuery.do",
	     type : "post",
	     data:{"year":year},
	     dataType : "json",
	     success:function(result){
	    	 if(result.success){
	    		    $("#monthlyTable").bootstrapTable({
	    		   	 url: path+"/monthlyStatementController/monthlyDateQuery.do",
	    		   	 dataType:"json",
	    		   	 striped: false,
	    		   	 pagination: true,
	    		   	 paginationLoop:false,
	    		   	 queryParams: queryParams,
	    		   	columns : [{
	    				field : "year",
	    				title : "年",
	    				align : "center"
	    			},{
	    				field : "month",
	    				title : "月",
	    				align : "center",
	    				sortable: true
	    			},{
	    				field : "startLongDate",
	    				title : "开始日期",
	    				align : "center",
	    				formatter:function(value,row,index){
	    					if(""!=value){
	    				       return moment(value).format("YYYY-MM-DD HH:mm:ss");
	    					}
	    				}
	    			},{
	    				field : "endLongDate",
	    				title : "月结日期",
	    				align : "center",
	    				formatter:function(value,row,index){
	    					 if(""!=value){
	    						 //var thismonth=moment(new Date()).format("MM");
	    						 //if(thismonth<=row.month){
	    							 return "<a href=\"#\" style='text-decoration:underline;' name=\"enddate\" data-type=\"text\" data-pk=\""+row.year+row.month+"\" data-title=\"月结日期修改\">" + moment(value).format("YYYY-MM-DD HH:mm:ss") + "</a>";
	    						 //}else{
	    							// return moment(value).format("YYYY-MM-DD HH:mm:ss"); 
	    						 //}
	    					 }
	    				}
	    				
	    			}],
	    			 onLoadSuccess: function () {
	    				 layer.close(showdilog);
	    				 setThisMonthBackGroundColor("monthlyTable",new Date().getMonth()+1,"#EDEDED");
	    	                $("#monthlyTable a").editable({
	    	                    url: function (params) {
	    	                        $.ajax({
	    	                            type: 'POST',
	    	                            url: path+"/monthlyStatementController/monthlyUpdate.do",
	    	                            data: params,
	    	                            dataType: 'JSON',
	    	                            success: function (result) {
	    	                            	layer.msg(result.msg, {icon: 1, time:2000});
	    	                            	$("#monthlyTable").bootstrapTable('refresh');
	    	                            },
	    	                            error: function (result) {
	    	                            	 if(""!=result&&null!=result){
	    	                            		 layer.msg(result.msg, {icon: 2, time:2000});
	    	                    	    	 }else{
	    	                    	    		 layer.msg("系统繁忙,请稍后再试!", {icon: 2, time:2000}); 
	    	                    	    	 }
	    	                            }
	    	                        });
	    	                    },
	    	                    type: 'text',
	    	                    validate: function (value) { //字段验证
	    	                        if (!$.trim(value)) {
	    	                            return '日期不能为空';
	    	                        }
	    	                        if(""!=value){
	    	                        	if (!RQcheck(value)) {
	    	                        		return "正确日期格式：(yyyy-MM-dd HH:mm:ss)";
	    	                            }
	    	                        }
	    	                    }
	    	                });
	    	         },
	    	         onLoadError:function () {
	    	        	 layer.close(showdilog);
	    	        	 layer.msg("系统繁忙,请稍后再试!", {icon: 2, time:2000}); 
	                 },
	            	 showExport: true,
	            	 exportDataType:'basic',
	            	 exportTypes : [ 'excel'],
	            		//表格导出数据设置
	            		exportOptions : {
	            			//忽略列ignoreColumn : [ 0, 0 ],
	            			fileName : "月结日期"+new Date().toLocaleString(),
	            			worksheetName : "月结日期",
	            			tableName : "月结日期"
	            	 },
	    			 sidePagination : "server", //表示服务端请求
	    			 sortName:"month",
	    			 sortOrder:"asc",
	    		   	 pageNumber:1,  //初始化加载第一页，默认第一页  
	    		     pageSize: 12,  //每页的记录行数（*）  
	    		     sidePagination : "server",
	    		     pageList: [12,24,48], //可供选择的每页的行数（*）
	    		     showColumns : false, // 是否显示所有的列
	    			 showRefresh : false, // 是否显示刷新按钮
	    			 uniqueId :"month"// 每一行的唯一标识，一般为主键列，
	    		    });
	    	 }else{
	    		 layer.close(showdilog);
	    		 layer.msg(result.msg, {icon: 2, time:2000}); 
	    	 }
	     },
	     error:function(result){
	    	 layer.close(showdilog);
	    	 if(""!=result&&null!=result){
	    		 layer.msg(result.msg, {icon: 2, time:2000}); 
	    	 }else{
	    		 layer.msg("系统繁忙,请稍后再试!", {icon: 2, time:2000}); 
	    	 }
	     }
	 });
	
}


//将当前月的行高亮背景颜色显示
function setThisMonthBackGroundColor(tableId,thisMonth,Color){
    var table = document.getElementById(tableId);
    for(var i=1;i<table.rows.length;i++){
    	if($(table.rows[i]).attr("data-uniqueid")==thisMonth){
    	    table.rows[i].setAttribute("style","background:"+Color+";");
    	}
    }
}

/*时间验证*/
function RQcheck(RQ) {
	var regex=/^(?:19|20)[0-9][0-9]-(?:(?:0[1-9])|(?:1[0-2]))-(?:(?:[0-2][1-9])|(?:[1-3][0-1])) (?:(?:[0-2][0-3])|(?:[0-1][0-9])):[0-5][0-9]:[0-5][0-9]$/;
	if(!regex.test(RQ)){
	return false;
	}
	return true;
/*    var date = RQ;
    var result = date.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);

    if (result == null)
        return false;
    var d = new Date(result[1], result[3] - 1, result[4]);
    return (d.getFullYear() == result[1] && (d.getMonth() + 1) == result[3] && d.getDate() == result[4]);
*/
}

/*格式化时间*/
$('.datepicker').datepicker({
	startView: 2,  
	maxViewMode: 2,
	minViewMode:2,
    format: "yyyy",
    todayBtn: "linked",
    clearBtn:true,
    autoclose:true,//加上这个参数
    language: "zh-CN"
});