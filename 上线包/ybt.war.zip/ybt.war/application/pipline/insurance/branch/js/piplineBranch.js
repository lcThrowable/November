
var select2 = '请选择';
var tab_d = $('#cusTable');
var count = 1;
var countchange= 1;
$(function(){
	//加载网点
	$.ajax({
		url : path + "/pipline/insurance/branch/selectAllCitys.do",
		type : "POST",
		dataType : "json",
		success : function(data) {
			for (var i = 0; i < data.length; i++) {
				$("#insuranceCompany").append(
						"<option value=" + data[i].citycode + ">"
								+ data[i].cityname + "</option>");
			}
		},
		error : function() {
			alert("城市代码失败!");
		}
	});			
	
	$("#insuranceCompany").change(function() {
		var insuranceCompany = ($(this).children('option:selected').val().trim());
		select2 = insuranceCompany;
		countchange = 2;
	});

	
	
	/**
	 * 方法简介：1.查询分行
	 *        2.显示授权信息
	 */
	$("#search").click(function(){
		
		var staffId = $("#StaffId").val();	
		if(staffId==null||staffId==""){
			alert("staffId 不能为空");
			return;
		}
		if(select2=='请选择'){
			select2="";
		}
		$("#cusTable").bootstrapTable('destroy');
		 
		/*校验sfaffid是否存在*/
		$.ajax({
			url : path + "/pipline/insurance/branch/checkstaffId.do",
			type : "POST",
			dataType : "json",
			data : "staffId="+staffId,	
			success : function(data) {
				if(data.success){				
				url_d = "/pipline/insurance/branch/selectBanches.do";
				tableInit3(url_d, tab_d, col, uniqueId, queryParams);				
				count =2;
				countchange =1
				}else{
				  alert(data.msg);
				  return;
				}
			},
			error : function() {
				alert("查询异常!");
			}
		});									
	});
	
	/**
	 * 授权按钮点击事件
	 */
	
	$("#grant").click(function(){
		var staffId = $("#StaffId").val();	
		if(staffId==null||staffId==""){
			alert("staffId 不能为空");
			return;
		}
		var jsonData = new Array();
		var data = tab_d.bootstrapTable('getSelections');			
		var staff  ={"staffId" : staffId,
				     "cityCode": select2 };
		jsonData.push(staff);
		for(var i=0;i<data.length;i++){
			var tr = {
				"branchCode" : data[i].branchCode,
				"branchName" : data[i].branchName,
				"cityCode"   : data[i].cityCode,
			};
			jsonData.push(tr);
		}		
		$.ajax({
			url : path + "/pipline/insurance/branch/checkstaffId.do",
			type : "POST",
			dataType : "json",
			data : "staffId="+staffId,	
			success : function(data) {			
				if(data.success){
				if(countchange===2){
					alert("请先点击查询按钮后，再进行授权！");
					return;
				}	
				if(count!=2){
					alert("请先点击查询按钮后，再进行授权！");
					return;
				}		
				/*获取table的值*/
				var allTableData = $("#cusTable").bootstrapTable('getData');
				if(allTableData.length===0){
					alert("无可授权的数据");
					return;
				}
				if (!confirm("确定要提交授权信息吗?")) {
					return;
				}
				/*后台权限授权操作*/
				$.ajax({
					url : path + "/pipline/insurance/branch/insertSelectives.do",
					type : "POST",
					dataType : "json",
					contentType : 'application/json;charset=utf-8',
					data : JSON.stringify(jsonData),
					traditional : true,
					success : function(data) {			
							alert(data.msg);				
					},
					error : function() {
						alert("授权失败!");
					}
					});					
				}else{
				  alert(data.msg);
				  return;
				}
			},
			error : function() {
				alert("查询异常!");
			}
		});												
	});
	
	var col = [{
		 checkbox: true,
		 formatter:stateFormatter 
	}, {
		field : 'id',
		title : '序号',
		formatter : function(value, row, index) {
			return index + 1;
		}
	}, {
		field : 'branchCode',
		title : '分行代码',
		align : 'center',
		valign : 'middle',
		visible : true
	}, {
		field : 'branchName', 
		title : '分行名称',
		align : 'center',
		valign : 'middle',
		visible : true
	}, 
	{
		field : 'cityCode', 
		title : '城市代码',
		align : 'center',
		valign : 'middle',
		visible : false
	}
	];
	var uniqueId = "metentid";
	
	function queryParams(params) {
		// 设置查询参数
		var param = {
				staffId : $("#StaffId").val(),
				address : select2
		};
		return param;
	};
	
	function tableInit3(url, obj, col, uniqueId, queryParams) {
		obj.bootstrapTable({
			url : path + url, // 请求后台的URL（*）
			dataType : "json",
			method : 'post', // 请求方式（*）
			contentType : "application/x-www-form-urlencoded",
			toolbar : '#toolbar',
			columns : col,
			striped : true, // 是否显示行间隔色
			cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
			queryParams : queryParams,// 传递参数（*）
			strictSearch : false,// 设置为 true启用 全匹配搜索，否则为模糊搜索
			minimumCountColumns : 2, // 最少允许的列数
			clickToSelect : true, // 是否启用点击选中行
			uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
			showToggle : true, // 是否显示详细视图和列表视图的切换按钮
			cardView : false, // 是否显示详细视图
			detailView : false
		});
	};
	
});

function stateFormatter(value, row, index) {  
    if (row.status == true)  
        return {  
            checked : true//设置选中  
        };  
     
} 