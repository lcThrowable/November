var recordingFlag = ""; //全局变量：补录标记，Y为补录单，N为正常单
var pipelineFlag="";//Y 已关联
//按钮初始化
$(document).ready(function() {
	var proposalcontno =initFormdata.newContApply.proposalcontno;
	var flag =initFormdata.newContApply.flag;
	recordingFlag =initFormdata.newContApply.recording;	//补录标记
	pipelineFlag =initFormdata.newContApply.pipelineflag;	//补录标记
	try {
		if(flag=='5'){
			buttonControl_4();
		}else{
			try {
				buttonControl(proposalcontno);
			} catch (e) {
				// TODO: handle exception
			}
		}
	} catch (e) {
		// TODO: handle exception
	}
/*	try {
		delayDebitTime(proposalcontno);
	} catch (e) {
		// TODO: handle exception
	}	*/
});

var uploadData ="";
var showdilog="";
//Dropzone.options.myAwesomeDropzone = false; 
Dropzone.autoDiscover = false;
$("#upfilezone").dropzone({
	url:path+"/contUploadController/PALIcontDocUpload.do",
    addRemoveLinks: true,
    method: 'post',
//    timeout:600000,
    enctype:"multipart/form-data",
    filesizeBase: 1000,
    dictRemoveFile:"移除文件",
    dictCancelUpload: "取消上传",
    autoProcessQueue:false,
    acceptedFiles: ".pdf",
    dictInvalidFileType: "仅支持.pdf类型文件上传.",
    thumbnailWidth:100,
    thumbnailHeight:100,
    maxThumbnailFilesize:5,
    maxFiles:30,
    maxFilesize:40,
    uploadMultiple:true,
    parallelUploads:30,
    previewTemplate: document.querySelector('#preview-template').innerHTML,
    sendingmultiple: function(file, xhr, formData) {
    	var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
    	var insurancecom=vueobj["testdivchange"].formdata.newContApply.insurancecom;
    	var transno =vueobj["testdivchange"].formdata.newContApply.transno;
    	formData.append("filesize", file.size);
        formData.append("proposalcontno", proposalcontno);
        formData.append("transno", transno);
        formData.append("insurancecom", insurancecom);
    },
    init: function() {
        var submitButton = document.querySelector("#upFiles");
        var upstatus = true;
        dropzoneObj = this;
        
    	submitButton.addEventListener("click", function() {
    		if(dropzoneObj.files!=null&&dropzoneObj.files!=""){
    			showdilog= layer.load(0, {
   			  shade: [0.1,'#fff'] //0.1透明度的白色背景
    		   });
    		}
				dropzoneObj.processQueue(); 
    	
		});
    	
    	this.on("canceled", function(file) {
    		var _ref;
    		$.ajax({
    			url:path+"/contUploadController/removeUpDoc.do",
    			type:"POST",
    			data:{"upcode":uploadData.map.upcode,
    				  "contno":uploadData.map.contno},
    			success:function(data){
    				dropzoneObj.reset();
    				layer.close(showdilog);   
    			}
    		});
    		this.files.length=0;
    	    return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
		});
    	
    	this.on("addedfile",function(file){
    		console.info("file.type : "  + file.type );
    		if(file.type != "application/pdf"){
    			upstatus = false;
    		}else{
    			upstatus = true;
    		};
    		
	    	!upstatus?$("#upFiles").attr("disabled",true):$("#upFiles").removeAttr("disabled");
    	});
    	
    	this.on("removedfile", function(file) {

//    		if(uploadData!=""){
//        		$.ajax({
//        			url:path+"/contUploadController/removeUpDoc.do",
//        			type:"POST",
//        			data:{"upcode":uploadData.map.upcode,
//        				  "contno":uploadData.map.contno},
//        			success:function(data){
//        				uploadData="";
//        				var _ref;
//        				var reg=/ /g;
//        				if(data.parm == 'undefined' || data.parm == undefined){
//                            alert("Time out,please login again!");
//                        }else{
//                            alert("系统成功"+data.parm);
//                        }
//
//        				//移除当前页面所有上传的文件元素
//        				return (_ref = file.previewElement) != null ? _ref.className!=null?$("."+_ref.className.replace(reg,'.')).remove():void 0 : void 0;
//        			},
//        			error:function(data){
//        				console.log(data);
//        			}
//        		});
//    		}else{
    			var _ref;
    			//仅移除单个文件
    			(_ref = file.previewElement) != null ? _ref.parentNode!=null?_ref.parentNode.removeChild(file.previewElement):void 0 : void 0;
        		
    			var upfiles = this.files;
    	    	var len = 0;
    	    	var check = 0;
    	    	for(var j = 0,len=upfiles.length; j < len; j++) {
    	    		if(upfiles[j].accepted)check++;
    	    	}
    	    	
    	    	if(len==check){
    	    		upstatus = true;
    	    	}else{
    	    		upstatus = false;
    	    	};
    	    	
    	    	!upstatus?$("#upFiles").attr("disabled",true):$("#upFiles").removeAttr("disabled");
//    		}

		}); 
    	
    	this.on("successmultiple", function(file, response, e){
    		console.log("PALI upload return type ===" + typeof(response));
    		if(typeof(response) == "string"){
    			response = JSON.parse(response);
    		}
			var reg=/ /g;
			var _ref;
			var dropzoneObj =this;
			var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
			var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
			(_ref = file[0].previewElement) != null ? _ref.className!=null?$("."+_ref.className.replace(reg,'.')).remove():void 0 : void 0;
			uploadData=response.success?response:"";
			this.files.length=0;
            var resultMsg = response.msg;
            console.log("++++"+response.msg+"******");
            if(resultMsg == 'undefined' || resultMsg == undefined){
            	layer.close(showdilog);
                alert("Time out,please login again!");
            }else{
            	layer.close(showdilog);
                alert(response.msg);
            } 
			if(response.success){
				$.ajax({
			        type : "POST",
			        url:path+'/contsubmitController/Elenotif.do',// 后台请求URL地址
			        data : {"proposalcontno":proposalcontno,"sleepflag":"Y","insurancecom":insurancecom},
			        dataType : "json",
			        success : function(data) {
			        	layer.close(showdilog);
			        	console.log("上传通知交易成功");
			        },
			        error:function(){
			        	layer.close(showdilog);
			        	console.log("上传通知交易失败");
			        }
			        });
			}			 
		});
    	this.on("completemultiple",function(){
    		try {
    			layer.close(showdilog);
			} catch (e) {
				// TODO: handle exception
			}
   		 
   	    }); 
    	this.on("maxfilesreached",function(){
    		alert("文件数量达到最大数量,请确认上传的文件.");
    	});    	  	
  }
    
});




/*投保单打印*/
function printPol_PALI(){
	var transNo =initFormdata.newContApply.transno;
	var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
	var riskcode=vueobj["testdivchange"].formdata.lccont.riskcode;
	var managecom = vueobj["testdivchange"].formdata.lccont.managecom;
	var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
	var transno = vueobj["testdivchange"].formdata.lccont.transno;
	var investment = initFormdata.newContApply.investment;
	var grpcontno = vueobj["testdivchange"].formdata.lccont.grpcontno;
//	console.log("投保单号："+proposalcontno);
//	console.log("险种代码："+riskcode);
//	console.log("机构："+managecom);
//	console.log("保险公司："+insurancecom);
//	console.log("投保单打印流水号："+transno);
//	console.log("多被保人标志："+investment);
//	console.log("客户号："+grpcontno);
	if(confirm("您确定要打印投保单号："+proposalcontno+"?")){
         var url= path+"/newContEnter/printLccont.do?contNo" +
         		"="+proposalcontno+"&riskCode="+riskcode+"&managecom="+managecom+"&insurancecom="+insurancecom
         		+"&transno="+transno+"&investment="+investment+"&grpcontno="+grpcontno;
    		  
  			if (!!window.ActiveXObject || "ActiveXObject" in window){
  				//ie
  				 window.open('javascript:window.name;', '<script>window.location.replace("'+url+'")<\/script>');
  			}else{
  				//google
  				 window.open(url,"_blank");
  			}
  		    
  		
     }
	$.ajax({
		type : "POST",
		url:path+'/SFPJsonSend/JsonSend.do',
		data: {"transNo":transNo},
		dataType : "json",
		success:function(data) {
			var response=JSON.parse(data);
			if(response.status=="SUCCESS"){
				alert("成功/Succeed");
			}else if(response.errorInfo[0].code!="OIM0042"){
				alert("同步SFP失败/Failed to update \n"+data);
			}
		},
		 error:function(){ 
			 alert("双录停止失败！");
		 }
	});
}

/*试算*/
function submitTentative_anzl(){
	var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
	var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
	var r=confirm("是否要进行试算?");	
	if(r==false){
		return;
	}
	var showdilog= layer.load(0, {
		  shade:0.3, //0.3透明度的白色背景
	   });
	$.ajax({
        type : "POST",
        url:path+'/contsubmitController/Tentative.do',// 后台请求URL地址
        data : {"proposalcontno":proposalcontno,"insurancecom":insurancecom},
        dataType : "json",
        success : function(data) {
        	if(data.success){      		
        		if(data.parm=="1222"){
        			 layer.close(showdilog);
        	         initNRealtime(true); //初始化弹窗
                     $("#modalBody").append('<span style="color: #4f4f4f;">此单需非实时核保，继续投保点击"转人工核保"，放弃投保点击"返回修改"，取消投保点击"取消投保"，原因：'+data.msg+'</span>');           
                     $('#myModal3').attr('class', "modal show");
        		}else if(data.parm=="1234"){
        			 layer.close(showdilog);
        			 initNRealtime(false); //初始化弹窗
        		     $("#modalBody").append('<span style="color: #4f4f4f;">试算失败，原因：'+data.msg+'</span>');           
                     $('#myModal3').attr('class', "modal show");
        		}else if(data.parm=="0000"){       			       			
        			layer.close(showdilog);
        			layer.alert(data.msg);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
        			buttonControl(proposalcontno);//按钮状态查询 
        	    	//pipline框
        	    	/*layer.alert(data.msg,function(){

        	    		layer.confirm('是否关联Pipeline？', {
        	  			  btn: ['关联','取消'] //按钮
        	  			}, function(){
        	  				 layer.close(layer.index);
        	  				 pipelineModel_show();
        	  			});

        	    	});*/
        		}      		
        	}else{
        		layer.close(showdilog);
        		layer.alert(data.msg);
        		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
        	}
        },
        error:function(){
        	layer.close(showdilog);
        	alert("试算失败！");
        	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
            
        }
 });
}


//初始化非实时申请弹窗的状态，清除选中状态，按钮变成不可点击，清空div下面的提示内容
function initNRealtime(flag){
	if(flag){
		$(".modalOfDiv1").show(); //清除checkbox选中状态
		$("#NRealtime").show();
		$(".modalOfDiv3").css("float","left");
		$("#isNRealtime").attr("checked",false); //清除checkbox选中状态
		$("#NRealtime").attr("disabled",true); //转非实时按钮不可点击
		$("#NRealtime").removeClass("btn btn-primary");
		$("#NRealtime").addClass("btn btn-primaryis");
	/*	$("#iscancel").attr("disabled",true); //转非实时按钮不可点击
		$("#iscancel").removeClass("btn btn-primary");
		$("#iscancel").addClass("btn btn-primaryis");*/ 
		$("#modalBody").empty(); //清空div下面的内容
	}else{
		$(".modalOfDiv1").hide(); //清除checkbox选中状态
		$("#NRealtime").hide();
        $(".modalOfDiv3").css("float","right");
	/*	$("#iscancel").attr("disabled",true); //转非实时按钮不可点击
		$("#iscancel").removeClass("btn btn-primary");
		$("#iscancel").addClass("btn btn-primaryis");*/ 
		$("#modalBody").empty(); //清空div下面的内容
	}

}

//非实时弹窗点击返回录入,关闭窗口
$("#return2page").click(function(){
	$('#myModal3').attr('class', "modal flad"); //关闭弹窗
});

//非实时弹窗的转非实时按钮控制
$("#isNRealtime").click(function(){
	if($("#isNRealtime").is(":checked")==true){ //勾选,走非实时按钮可以点击
		$("#NRealtime").removeAttr("disabled"); 
		$("#NRealtime").removeClass("btn btn-primaryis");
		$("#NRealtime").addClass("btn btn-primary");
	}else{ //未勾选状态，按钮不可以点击
		$("#NRealtime").attr("disabled",true); 
		$("#NRealtime").removeClass("btn btn-primary");
		$("#NRealtime").addClass("btn btn-primaryis");
	}
});
/*//取消投保
$("#isNRealtime").click(function(){
	if($("#isNRealtime").is(":checked")==true){ //勾选,走非实时按钮可以点击
		$("#iscancel").removeAttr("disabled"); 
		$("#iscancel").removeClass("btn btn-primaryis");
		$("#iscancel").addClass("btn btn-primary");
	}else{ //未勾选状态，按钮不可以点击
		$("#iscancel").attr("disabled",true); 
		$("#iscancel").removeClass("btn btn-primary");
		$("#iscancel").addClass("btn btn-primaryis");
	}
});*/
//点击转人工核保按钮触发
$("#NRealtime").click(function(){
	$('#myModal3').attr('class', "modal flad"); //关闭弹窗
	var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
	var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
	var showdilog= layer.load(0, {
		  shade: [0.1,'#fff'] //0.1透明度的白色背景
	   });
	//非实时操作
	$.ajax({
	    url:path + '/newContApply/resetAppFlagStatus.do',  
	    type: "POST",
	    data: {"proposalcontno":proposalcontno,"insu":insurancecom},
	    dataType : "json",
	    success: function(data){
	    	layer.close(showdilog);
	    	layer.alert(data.msg);
	    	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
	    	buttonControl(proposalcontno);//按钮状态查询 
	    	//pipline框
	    	/*layer.alert(data.msg,function(){

	    		layer.confirm('是否关联Pipeline？', {
	  			  btn: ['关联','取消'] //按钮
	  			}, function(){
	  				 layer.close(layer.index);
	  				 pipelineModel_show();
	  			});

	    	});*/
		
	    },
	    error:function(){
	    	layer.close(showdilog);
	    	layer.alert("非实时投保确认失败!");
	    	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
	    	buttonControl(proposalcontno);//按钮状态查询 
	    	
	    }
	}); 
});

//取消投保
$("#iscancel").click(function(){
	$('#myModal3').attr('class', "modal flad"); //关闭弹窗
	var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
	if(!confirm("您确定要取消此次投保："+proposalcontno+"?")){
		buttonControl(proposalcontno);//按钮状态查询 
		return;
	}else{
		//非实时操作
		$.ajax({
		    url:path + '/newContApply/cancelInsure.do',  
		    type: "POST",
		    data: {"proposalcontno":proposalcontno},
		    dataType : "json",
		    success: function(data){
		    	alert(data.msg);
		    	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
				vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
		    	buttonControl(proposalcontno);//按钮状态查询 
		    	
		    }
		}); 
	}	
});


/*延迟扣款*/
/*function delayDebit_anzl(){

    var matter="延迟扣款";
    var DelayedDate=$("#DelayedDate").val();

    if(DelayedDate==null||DelayedDate==""){
        alert("请输入延迟扣款时间");
        return false;
    }
    var date=new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + new Date().getDate();
    if(Datecompare1(date,DelayedDate)==false){
        alert("延迟扣款时间必须晚于今天");
        return false;
    }
    var r=confirm("核保成功,请确认投保单已打印");
    if (r==false)
    {
        return false;
    }else{
    	var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
    	showdilog= layer.load(0, {
 			  shade: [0.1,'#fff'] //0.1透明度的白色背景
  		   });
        $.ajax({
            url:path + '/contsubmitController/DelayedPingAn.do',
            type: "POST",
            data:{"DelayedDate":DelayedDate,"proposalcontno":proposalcontno,"matter":matter},
            success: function(data){          	
                if(data.success){               	
                	layer.close(showdilog);
                	 alert("投保单号为："+data.parm+","+data.msg);
                	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
                	buttonControl(proposalcontno);//按钮状态查询 
                	$("#DelayedDate").val(DelayedDate);
                    $("#DelayedDate").attr("disabled",true);
                   
                }else{
                	layer.close(showdilog);
                	layer.alert(data.msg);
                	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
        			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
                	buttonControl(proposalcontno);//按钮状态查询 
                   
                }
            },
            error:function(){
            	layer.close(showdilog);
            	layer.alert("延迟扣款交易失败");
            	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
            	buttonControl(proposalcontno);//按钮状态查询 
                
            }
        });
    }
}*/
/*扣款*/
function debit_anzl(){

	var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
	var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
	var transno = vueobj["testdivchange"].formdata.lccont.transno;
//	var DelayedDate =$("#DelayedDate").val();  
    var r=confirm("核保成功，请确认投保单已打印,客户同意扣款");
    if (r==false)
    {
        return false;
    }else{
    	showdilog= layer.load(0, {
 			  shade: [0.1,'#fff'] //0.1透明度的白色背景
  		   });
    }         
    $.ajax({
        type : "POST",
        url:path+'/contsubmitController/Elenotif.do',// 后台请求URL地址
        data : {"proposalcontno":proposalcontno,"insurancecom":insurancecom},
        dataType : "json",
        success : function(data) {
            if(data!=null){
                if(data.success==true){ //数据正确，返回按钮状态
                	$.ajax({
                        type : "POST",
                        url:path+'/contsubmitController/debitReal.do',// 后台请求URL地址
                        data : {"proposalcontno":proposalcontno,"transno":transno},
                        dataType : "json",
                        success : function(data) {
                        	if(data.success==true){
                        		layer.close(showdilog);
                        		layer.alert(data.msg); 
                        		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
                    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
                    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
                    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
                            	buttonControl(proposalcontno);//按钮状态查询                       	                                             	
                        	}else{
                        		layer.close(showdilog);
                        		layer.alert(data.msg);
                        		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
                    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
                    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
                    			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
                            	buttonControl(proposalcontno);//按钮状态查询                       	                                             	
                                
                        	}                       	                          
                        },
                        error:function(){
                        	layer.close(showdilog);
                        	layer.alert("扣款失败");
                        	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"appflag",data.appflag);
                			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"chargecode",data.chargecode);
                			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"appflag",data.appflag);
                			vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.newContApply,"chargecode",data.chargecode);
                        	buttonControl(proposalcontno);//按钮状态查询  
                            
                        }
                    });                                                       
                }else{ //数据不正确，不能进行操作
                	layer.close(showdilog);               
                    alert(data.msg);
                }
            }else{
            	layer.close(showdilog);
            	alert(data.msg);
            	}         
        } ,
        error:function(){
        	layer.close(showdilog);
            alert("YBT系统异常");
        }
    });                              
}

function Datecompare1(stateDate1,endDate1){
    var startDate=stateDate1.split("-");
    var startDateTemp=new Date(startDate[0],startDate[1]-1,startDate[2]);
    var endDate=endDate1.split("-");
    var endDateTemp=new Date(endDate[0],endDate[1]-1,endDate[2]);
    if(startDateTemp.getTime()>=endDateTemp.getTime()){
        return false;
    }else{
        return true;
    }
}

/* 按钮状态控制
 * 
 * 1> 试算 打印投保单   上传投保单    扣款  延迟扣款 均能点击。
 * 
 * 2> 打印投保单   上传投保单    扣款 能点  试算    延迟扣款 不能点。
 * 
 * 3> 打印投保单   上传投保单 能点 试算     扣款  延迟扣款 不能点击。
 * 
 * 4> 试算 打印投保单   上传投保单    扣款  延迟扣款 均不能点。
 *
 * 5> 只能试算
 * */
 function buttonControl(proposalcontno){
		$.ajax({
			type : "POST",
			url:path + '/contsubmitController/QueryButtonFlag.do',  
			data : {"proposalcontno":proposalcontno},
			dataType : "json",
			async: false,
			success:function(data) {
				if(data!=null){
					if(data.success==true){ //数据正确，返回按钮状态
						if(data.parm=="1"){
							buttonControl_1();
						}else if(data.parm=="2"){
							buttonControl_2();
						}else if(data.parm=="3"){
							buttonControl_3();
						}else if(data.parm=="5"){
							buttonControl_5();
						}else{
							buttonControl_4();
						}
					}else{
						buttonControl_4();
					}
				}else{
					buttonControl_4();
				}
			},
			 error:function(){ 
             	buttonControl_4();//按钮状态查询  
             }
		});
	}
    // 1>试算  打印投保单   上传投保单    扣款  延迟扣款 均能点击
	function buttonControl_1(){
		//试算
		$("#tentative").attr("disabled",true);  
		$("#tentative").removeClass("btn btn-primary");
		$("#tentative").addClass("btn btn-primaryis");
		//打印	
		$("#printPol").removeAttr("disabled");
		$("#printPol").removeClass("btn btn-primaryis");
		$("#printPol").addClass("btn btn-primary");
		//上传
		$("#polupload").removeAttr("disabled"); 
		$("#polupload").removeClass("btn btn-primaryis");
		$("#polupload").addClass("btn btn-primary");
		
		/*//停止双录	
		$("#closePol").removeAttr("disabled");
		$("#closePol").removeClass("btn btn-primaryis");
		$("#closePol").addClass("btn btn-primary");*/
		
		//扣款
		$("#debit").removeAttr("disabled");
		$("#debit").removeClass("btn btn-primaryis");
		$("#debit").addClass("btn btn-primary");
		/*//延迟扣款
		$("#delayeddebit").removeAttr("disabled");
		$("#delayeddebit").removeClass("btn btn-primaryis");
		$("#delayeddebit").addClass("btn btn-primary");
		//延迟扣款日期可选
		$("#DelayedDate").removeAttr("disabled");*/
		
		if(recordingFlag == "Y"){//补录单
			//打印不可点
			$("#printPol").attr("disabled",true);  
			$("#printPol").removeClass("btn btn-primary");
			$("#printPol").addClass("btn btn-primaryis");
			//上传不可点
			$("#polupload").attr("disabled",true);  
			$("#polupload").removeClass("btn btn-primary");
			$("#polupload").addClass("btn btn-primaryis");
			//扣款不可点
			$("#debit").attr("disabled",true);  
			$("#debit").removeClass("btn btn-primary");
			$("#debit").addClass("btn btn-primaryis");
			/*//停止双录不可点
			$("#closePol").attr("disabled",true);  
			$("#closePol").removeClass("btn btn-primary");
			$("#closePol").addClass("btn btn-primaryis");*/
		}
		
		if(pipelineFlag=="Y"){
			$("#relevancePipeline").attr("disabled",true);
			$("#relevancePipeline").removeClass("btn btn-primary");
			$("#relevancePipeline").addClass("btn btn-primaryis");
		}else{
			//关联Pipeline
			$("#relevancePipeline").removeAttr("disabled");
			$("#relevancePipeline").removeClass("btn btn-primaryis");
			$("#relevancePipeline").addClass("btn btn-primary");
		}
		
	}
	//试算 打印投保单   上传投保单    扣款  延迟扣款 均不能点。
	function buttonControl_2(){		
		//打印	
		$("#printPol").removeAttr("disabled");
		$("#printPol").removeClass("btn btn-primaryis");
		$("#printPol").addClass("btn btn-primary");
		//上传
		$("#polupload").removeAttr("disabled"); 
		$("#polupload").removeClass("btn btn-primaryis");
		$("#polupload").addClass("btn btn-primary");
		/*//停止双录	
		$("#closePol").removeAttr("disabled");
		$("#closePol").removeClass("btn btn-primaryis");
		$("#closePol").addClass("btn btn-primary");*/
		
		//扣款
		$("#debit").removeAttr("disabled");
		$("#debit").removeClass("btn btn-primaryis");
		$("#debit").addClass("btn btn-primary");
		//延迟扣款
	/*	$("#delayeddebit").attr("disabled",true);
		$("#delayeddebit").removeClass("btn btn-primary");
		$("#delayeddebit").addClass("btn btn-primaryis");*/		
		//试算
		$("#tentative").attr("disabled",true);  
		$("#tentative").removeClass("btn btn-primary");
		$("#tentative").addClass("btn btn-primaryis");
		//延迟扣款日期置灰
		/*$("#DelayedDate").attr("disabled",true);*/
		if(recordingFlag == "Y"){//补录单
			//打印不可点
			$("#printPol").attr("disabled",true);  
			$("#printPol").removeClass("btn btn-primary");
			$("#printPol").addClass("btn btn-primaryis");
			//上传不可点
			$("#polupload").attr("disabled",true);  
			$("#polupload").removeClass("btn btn-primary");
			$("#polupload").addClass("btn btn-primaryis");
			//扣款不可点
			$("#debit").attr("disabled",true);  
			$("#debit").removeClass("btn btn-primary");
			$("#debit").addClass("btn btn-primaryis");
			/*//停止双录不可点
			$("#closePol").attr("disabled",true);  
			$("#closePol").removeClass("btn btn-primary");
			$("#closePol").addClass("btn btn-primaryis");*/
		}
		
	}

	//打印投保单   上传投保单 能点 试算     扣款  延迟扣款 不能点击。
	function buttonControl_3(){
		//打印	
		$("#printPol").removeAttr("disabled");
		$("#printPol").removeClass("btn btn-primaryis");
		$("#printPol").addClass("btn btn-primary");
		//上传
		$("#polupload").removeAttr("disabled"); 
		$("#polupload").removeClass("btn btn-primaryis");
		$("#polupload").addClass("btn btn-primary");
		
		/*//停止双录	
		$("#closePol").removeAttr("disabled");
		$("#closePol").removeClass("btn btn-primaryis");
		$("#closePol").addClass("btn btn-primary");*/
		//扣款
		$("#debit").attr("disabled",true);
		$("#debit").removeClass("btn btn-primary");
		$("#debit").addClass("btn btn-primaryis");
		//延迟扣款
	/*	$("#delayeddebit").attr("disabled",true);
		$("#delayeddebit").removeClass("btn btn-primary");
		$("#delayeddebit").addClass("btn btn-primaryis");*/
		//试算
		$("#tentative").attr("disabled",true);
		$("#tentative").removeClass("btn btn-primary");
		$("#tentative").addClass("btn btn-primaryis");
		//延迟扣款日期置灰
		/*$("#DelayedDate").attr("disabled",true);*/
		
		if(recordingFlag == "Y"){//补录单
			//打印不可点
			$("#printPol").attr("disabled",true);  
			$("#printPol").removeClass("btn btn-primary");
			$("#printPol").addClass("btn btn-primaryis");
			//上传不可点
			$("#polupload").attr("disabled",true);  
			$("#polupload").removeClass("btn btn-primary");
			$("#polupload").addClass("btn btn-primaryis");
			/*//停止双录不可点
			$("#closePol").attr("disabled",true);  
			$("#closePol").removeClass("btn btn-primary");
			$("#closePol").addClass("btn btn-primaryis");*/
		}
		
		if(pipelineFlag=="Y"){
			$("#relevancePipeline").attr("disabled",true);
			$("#relevancePipeline").removeClass("btn btn-primary");
			$("#relevancePipeline").addClass("btn btn-primaryis");
		}else{
			//关联Pipeline
			$("#relevancePipeline").removeAttr("disabled");
			$("#relevancePipeline").removeClass("btn btn-primaryis");
			$("#relevancePipeline").addClass("btn btn-primary");
		}
		
	}
	//试算 打印投保单   上传投保单    扣款  延迟扣款 均不能点。
	function buttonControl_4(){			
		//打印	
		$("#printPol").attr("disabled",true);
		$("#printPol").removeClass("btn btn-primary");
		$("#printPol").addClass("btn btn-primaryis");
		//上传
		$("#polupload").attr("disabled",true); 
		$("#polupload").removeClass("btn btn-primary");
		$("#polupload").addClass("btn btn-primaryis");	
		
		/*//停止双录	
		$("#closePol").attr("disabled",true); 
		$("#closePol").removeClass("btn btn-primary");
		$("#closePol").addClass("btn btn-primaryis");*/	
		//扣款
		$("#debit").attr("disabled",true);
		$("#debit").removeClass("btn btn-primary");
		$("#debit").addClass("btn btn-primaryis");
		//延迟扣款
	/*	$("#delayeddebit").attr("disabled",true);
		$("#delayeddebit").removeClass("btn btn-primary");
		$("#delayeddebit").addClass("btn btn-primaryis");*/
		//试算
		$("#tentative").attr("disabled",true);
		$("#tentative").removeClass("btn btn-primary");
		$("#tentative").addClass("btn btn-primaryis");
		//延迟扣款日期置灰
		/*$("#DelayedDate").attr("disabled",true);*/

	}
	
	//只能试算    若为补录单，全部按钮不可用
	function buttonControl_5(){		
		//打印	
		$("#printPol").attr("disabled",true);
		$("#printPol").removeClass("btn btn-primary");
		$("#printPol").addClass("btn btn-primaryis");
		//上传
		$("#polupload").attr("disabled",true); 
		$("#polupload").removeClass("btn btn-primary");
		$("#polupload").addClass("btn btn-primaryis");
		
		/*//停止双录
		$("#closePol").attr("disabled",true); 
		$("#closePol").removeClass("btn btn-primary");
		$("#closePol").addClass("btn btn-primaryis");*/
		
		//扣款
		$("#debit").attr("disabled",true);
		$("#debit").removeClass("btn btn-primary");
		$("#debit").addClass("btn btn-primaryis");
		//延迟扣款
		/*$("#delayeddebit").attr("disabled",true);
		$("#delayeddebit").removeClass("btn btn-primary");
		$("#delayeddebit").addClass("btn btn-primaryis");*/
		//试算
		$("#tentative").removeAttr("disabled");   
		$("#tentative").removeClass("btn btn-primaryis");
		$("#tentative").addClass("btn btn-primary");
		//延迟扣款日期置灰
		/*$("#DelayedDate").attr("disabled",true);*/
		//若为补录单，试算按钮也置灰
		if(recordingFlag == "Y"){
			$("#tentative").attr("disabled",true);
			$("#tentative").removeClass("btn btn-primary");
			$("#tentative").addClass("btn btn-primaryis");
		}
	}
/*	function delayDebitTime(proposalcontno){
    	$.ajax({
			type : "POST",
			url:path + '/contsubmitController/selectdelayDate.do',  
			data : {"proposalcontno":proposalcontno},
			dataType : "json",
			success:function(data) {
				if(data.parm!=""&&data.parm!=null){
					$("#DelayedDate").val(data.parm);//延迟扣款时间
			        $("#DelayedDate").attr("disabled",true);
				}				
			},
			 error:function(){
             }
		});     	
    } */ 
	
	var col = [
{
  checkbox: true
},
{
field : 'piplineinfo.customerid',
title : '客户号' 
}, {
field : 'piplineinfo.appntname',
title : '客户姓名', 
},{
field : 'piplineinfo.riskcode',
title : '产品代码' ,
visible : true
},
{
field : 'piplineinfo.prem',
title : '年化保费' 
},{
field : 'piplineinfo.presigndate',
title : '预计签单日' 
}]; 

//关联Pipeline按钮
function submitrelevance_pipeline(){
	   pipelineModel_show();
}

//toolbar上关联按钮
$("#btn_relevance").click(function(){
	   var a= $("#pipline_table").bootstrapTable('getSelections');
		 if(a.length<=0){
			 layer.alert("请选中一行!")
		} else if(a.length>1){
			layer.alert("只能关联一个Pipeline!");
		}else{
			var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
			var transno=vueobj["testdivchange"].formdata.lccont.transno;
			var contno=vueobj["testdivchange"].formdata.lccont.contno;
			var b=JSON.stringify( a );
			  var url=path+"/pipline/insurance/piplineinfo/ybtRelevancePipline.do";
	  		    $.ajax({
	  		        data: {"listPipline":b,"transno":transno,"proposalcontno":proposalcontno,"contno":contno},
	  		        type: "post", 
	  		        url: url,
	  		        success : function (data) {
	  		            if(data.flag){
	  		      		 $("#pipline_Modal").modal('hide');
	  		            	layer.alert(data.desc);
	  		            	pipelineFlag="Y";
	  		            	buttonControl(proposalcontno);
	  		            }else{
	  		            	layer.alert(data.desc);
	  		            }
	  		      	  $("#pipline_table").bootstrapTable('destroy');
	  		        },
	  		        error : function (data){
	  		            alert("系统繁忙,请稍后再试！");
	  		        }
	  		    });
		} 
});


function pipelineModel_show(){
		  //显示表格
		$("#pipline_Modal").modal('show');
		var insurancecom=vueobj["testdivchange"].formdata.lccont.insurancecom;
		var agentcode=vueobj["testdivchange"].formdata.lccont.agentcode;
		var riskcode=vueobj["testdivchange"].formdata.lccont.riskcode;
		var grpcontno=vueobj["testdivchange"].formdata.lccont.grpcontno;
		//表格加载数据
		var url="/pipline/insurance/piplineinfo/ybtRelevancePiplineQuery.do";
	/*	url =url +"?"  +"piplineinfo.rmid="+agentcode+
	        "&piplineinfo.riskcode="+riskcode+"&piplineinfo.insurance="+insurancecom
	        +"&piplineinfo.customerid="+grpcontno;*/
		url =url +"?"  +"piplineinfo.rmid="+agentcode+
		"&piplineinfo.customerid="+grpcontno;
		tableInit(url,$("#pipline_table"),col,null,"piplineinfo.piplineno");
}
 
 
 function tableInit(url, obj, col,  queryParams,uniqueId) {
 	obj.bootstrapTable('destroy');
     obj.bootstrapTable({
         url : path + url, // 请求后台的URL（*）
         dataType : "json",
         method : 'GET', // 请求方式（*）
         contentType : "application/x-www-form-urlencoded",
         toolbar : '#toolbar',
         columns : col,
         striped : true, // 是否显示行间隔色
         cache : false, // 是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
         pagination : true, // 是否显示分页（*）
         queryParamsType : "limit",// undefined/limit
       //  queryParams : queryParams,// 传递参数（*）
         sidePagination : "server", //
         pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
         search : false, // 是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
         strictSearch : true,// 设置为 true启用 全匹配搜索，否则为模糊搜索
         showColumns : true, // 是否显示所有的列
         showRefresh : true, // 是否显示刷新按钮
         minimumCountColumns : 2, // 最少允许的列数
         clickToSelect : true, // 是否启用点击选中行
         // height: 500, //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
         // uniqueId: "ID", // 每一行的唯一标识，一般为主键列
         uniqueId : uniqueId, // 每一行的唯一标识，一般为主键列
         showToggle : true, // 是否显示详细视图和列表视图的切换按钮
         cardView : false, // 是否显示详细视图
         detailView : false,
     });
 };

 
 
 
/* //停止双录
 function close_PALI(){
	 var transNo=vueobj["testdivchange"].formdata.lccont.transno;
		$.ajax({
			type : "POST",
			url:path + '/SFPJsonSend/JsonSend.do',
			data: {"transNo":transNo},
			dataType : "json",
			success:function(data) {
				if(data!=""&&data=="200"){
					alert("双录停止成功！");
				}else{
					alert("Error:"+data);
				}
				
			},
			 error:function(){ 
          	//buttonControl_4();//按钮状态查询  
          }
		});
	}
 function sale(){
		openIframe("高保额问卷",path+'/application/newCont/SALE/sale.jsp');
	}*/