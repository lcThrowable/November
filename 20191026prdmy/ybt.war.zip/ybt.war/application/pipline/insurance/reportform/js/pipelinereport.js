/*格式化时间*/
$('.datepicker').datepicker({
	startView : 1,
	maxViewMode : 1,
	minViewMode : 1,
	format : "yyyymm",
	todayBtn : "linked",
	clearBtn : true,
	autoclose : true,//加上这个参数
	language : "zh-CN",
	pickerPosition : "bottom-left"// 清除按钮，和今天 按钮只能显示一个
});



$(function(){	
	$.ajax({
		url : path + "/pipline/EasyPOIController/company.do",
		type : "POST",
		dataType : "json",
		success : function(data) {
			for (var i = 0; i < data.length; i++) {
				$("#BX").append(
						"<option value=" + data[i].agentcom + ">"
								+ data[i].name + "</option>");
			}
		},
		error : function() {
			alert("城市代码失败!");
		}
	});	
	//点击查询加载bootstrap数据表格
	$("#search").click(function(){
		var year=$("#year").val().trim();
		var datetype = $("#datetype").val().trim();
		var succrate = $("#succrate").val().trim();
		var BX = $("#BX").val().trim();
		var ili = $("#ili").val().trim();
		  init(year,datetype,succrate,BX,ili);	
	});
	$("#down").click(function(){
		var showdilog= layer.load(2, {
			  shade:0.3, //0.2透明度的白色背景
		 });
		$.ajax({				
			type : "POST",
			url: path+"/pipline/EasyPOIController/down.do",// 后台请求URL地址	
			success : function(data) {
				if(data.success){
					var url ="download.jsp?path="+data.parm+"&a="+"sdf";
					toback(url);
					layer.close(showdilog);
				}else{
					alert(data.msg);
					layer.close(showdilog);
				}				
			},
			 error : function() {
			 alert("系统异常");
			 layer.close(showdilog);
			}
		});	
	});
	
});
function queryParams(params) { 
	// 设置查询参数
	var param = {
		limit : params.limit,
		offset : params.offset,
		sortName : params.sort,// 排序列名
		sortOrder : params.order,// 排位命令（desc，asc）
		pageSize : params.pageSize,
		pageNumber : params.pageNumber,
		year:$("#year").val().trim(),
		datetype:$("#datetype").val().trim(),
	    succrate : $("#succrate").val().trim(),
	    BX :  $("#BX").val().trim(),
	    ili : $("#ili").val().trim(),
	};
	return param;
};

var  $table=$("#cusTable");
function init(year,datetype,succrate,BX,ili){
	var showdilog= layer.load(2, {
		  shade:0.3, //0.2透明度的白色背景
	 });

	$table.bootstrapTable('destroy');
	
	$table.bootstrapTable({
		   	 url: path+"/pipline/EasyPOIController/export.do?year="+year+"&datetype"+datetype+"&succrate"+succrate+"&BX"+BX+"&ili"+ili,
		   	 dataType:"json",
		   	 striped: false,
		   	 pagination: false,
		   	 paginationLoop:false,
		   	 queryParams: queryParams,
		   	 idField: 'bankObjectId',
		   	rowStyle : function(row, index) {
         	   var  style = {};
					var strclass = row.rmstaffId;
					if (strclass == '') {
						style = {css:{"background-color":"Silver"}}						
					};
					return style;
          }, 
		   	 columns : [
		   	    {field: 'bankplace',title: '         区域        ',width:200,visible: true},
		   		{field: 'city',title: '市',align : "center",sortable: true},
		   		{field: 'branchName',title: '行',align: 'center',sortable: true,valign : 'middle'},
		   		{field: 'rmstaffId',title: 'staffid',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'sumpremEff',title: '生效',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'sumpremHes',title: 'CFI',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'sumpremUnd',title: '待核',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'sumpremCha',title: '待扣',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'amountPipe',title: '待签',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'amountTar',title: 'CMT',align: 'center',sortable: true,valign : 'middle',
   					formatter:function(value, row, index){
   						var datetype = $("#datetype").val().trim();  					
   							if(datetype=="ANP"){
   								return row.amountTar;
   							}else{
   								return row.revenueTar;
   							}
   						
   				    },
   				
   				},
   				{field: 'amountExp',title: 'LE',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'scale_E',title: 'LE%',align: 'center',sortable: true,valign : 'middle',
   					formatter:function(value, row, index){
   				        return row.scale_E;
   				    },
   				   cellStyle:function(value,row,index){ 
   					
   					   if(value){
   						 var n = value.substring(0,value.length-1);
   	             	    if (n<50){  
   	             	        return {css:{"background-color":"red"}}  
   	             	    }else if(n>=50 && n<=70){  
   	             	        return {css:{"background-color":"orange"}}  
   	             	    }else{
   	             	    	var  style = {};
   	    					var strclass = row.city;
   	    					if (strclass == '') {//偶数行
   	    						style = {css:{"background-color":"Silver"}}						
   	    					}
   	    					return style; 
   						   
   					   }
   					  
             	    }  else{
             	    	return {css:{"background-color":"Silver"}}		;
             	    }
             	} 				  				 
   				},
   				{field: 'runRate',title: 'RR',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'scale_R',title: 'RR%',align: 'center',sortable: true,valign : 'middle',
   					formatter:function(value, row, index){
   				        return row.scale_R;
   				    },
   				   cellStyle:function(value,row,index){ 
   					   
   					if(value){
   					   var n = value.substring(0,value.length-1);
             	    if (n<50){  
             	        return {css:{"background-color":"red"}}  
             	    }else if(n>=50 && n<=70){  
             	        return {css:{"background-color":"orange"}}  
             	    }else{
             	    	var  style = {};
    					var strclass = row.city;
    					if (strclass == '') {//偶数行
    						style = {css:{"background-color":"Silver"}}						
    					}
    					return style; 
             	    }  
             	    
   					}else{
   						return {css:{"background-color":"Silver"}}	;
   					}
             	}},
   				/*{field: 'scale_C',title: 'C%',align: 'center',sortable: true,valign : 'middle',
   					formatter:function(value, row, index){
   				        return row.scale_C;
   				    },
   				   cellStyle:function(value,row,index){ 
   					   var n = value.substring(0,value.length-1);
             	    if (n<50){  
             	        return {css:{"background-color":"red"}}  
             	    }else if(n>=50 && n<=70){  
             	        return {css:{"background-color":"orange"}}  
             	    }else{
             	    	var  style = {};
    					var strclass = row.city;
    					if (strclass == '') {//偶数行
    						style = {css:{"background-color":"Silver"}}						
    					}
    					return style;  
             	    }  
             	}},*/
   				{field: 'scale_A',title: '活动率',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'ticSize',title: '件均',align: 'center',sortable: true,valign : 'middle'},
   				{field: 'peoSize',title: '人均',align: 'center',sortable: true,valign : 'middle'},
		   		],
		   		 
             treeShowField: 'bankplace',
             
             parentIdField: 'parentBankObjectId',
			 onLoadSuccess: function (replydata) {	
				 
				 layer.close(showdilog);			 
	         },
	         onResetView: function(data) {
	                $table.treegrid({
	                    initialState: 'collapsed',// 所有节点都折叠
	                    treeColumn: 0,
	                    // expanderExpandedClass: 'glyphicon glyphicon-minus',  //图标样式
	                   //  expanderCollapsedClass: 'glyphicon glyphicon-plus',

	                    onChange: function() {
	                        $table.bootstrapTable('resetWidth');
	                    }
	                });	 
	            },
	           

	         onLoadError:function () {
	        	 layer.close(showdilog);
	        	 layer.msg("系统繁忙,请稍后再试!", {icon: 2, time:2000}); 
             },
             
			 //sidePagination : "server", //表示服务端请求
			 sortName:"month",
			 sortOrder:"asc",
		   	 //pageNumber:1,  //初始化加载第一页，默认第一页  
		     //pageSize: 12,  //每页的记录行数（*）  
		    // sidePagination : "server",
		     //pageList: [12,24,48], //可供选择的每页的行数（*）
		     showColumns : true, // 是否显示所有的列
			 showRefresh : true, // 是否显示刷新按钮
			 uniqueId : "id", // 每一行的唯一标识，一般为主键列
			 showToggle : true, // 是否显示详细视图和列表视图的切换按钮
			 cardView : false, // 是否显示详细视图
			 detailView : false
		    });	
}

