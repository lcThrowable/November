var vueobj=[];
var vue_config = [];
var vueMethods={};
var baseUrl ="/pipline/insurance/piplineinfo/info";
vue_config.push(
		{id : "piplineinfo"    , url : "/pipline/insurance/piplineinfo/pageinit" + piplineid} 
);
     
var afterVueSelect={};
var commonCombobox_option={};
 
 
vueMethods.submitPipline_SaveORUpdate=function ($event){
	
	var that = this;
	var type ="POST";
	
	var url = getRealURL(baseUrl,that.formdate,that);
	if(that.formdata.piplineinfo.piplineno!=undefined&&that.formdata.piplineinfo.piplineno!=""){
		
		type= "PUT";
		
	}else{
		type=="POST";
	}
	simpleAjaxREST(url,type,JSON.stringify(that.formdata));
}

 
 



